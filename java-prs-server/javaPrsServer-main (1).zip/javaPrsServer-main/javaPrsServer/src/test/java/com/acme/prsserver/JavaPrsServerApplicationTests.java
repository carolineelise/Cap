package com.acme.prsserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaPrsServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
