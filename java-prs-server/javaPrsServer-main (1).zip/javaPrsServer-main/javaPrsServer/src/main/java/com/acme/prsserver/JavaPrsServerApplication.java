package com.acme.prsserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaPrsServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaPrsServerApplication.class, args);
	}

}
